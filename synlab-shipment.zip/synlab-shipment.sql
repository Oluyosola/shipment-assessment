-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2023 at 09:01 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `synlab-shipment`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `userName`, `password`, `email`, `email_verified_at`, `created_at`, `updated_at`) VALUES
(1, 'oluyosola', '$2y$10$Zl4Joqc1Q1zP7r0LVuK4rOxSL5w0JIKpvVFMxfcrzoQUjYKRhb1e.', 'oluyosola@gmail.com', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `departmentName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `departmentShortName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `departmentCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `departmentName`, `departmentShortName`, `departmentCode`, `created_at`, `updated_at`) VALUES
(1, 'Technology', 'tech', NULL, '2023-01-20 10:14:26', '2023-01-20 10:14:26');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_region_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `name`, `location_region_id`, `created_at`, `updated_at`) VALUES
(1, 'Ilupeju BCP', 0, NULL, NULL),
(2, 'Luth lab', 0, NULL, NULL),
(3, 'HQ', 0, NULL, NULL),
(4, 'VI Lab', 0, NULL, NULL),
(5, 'Lekki Lab', 0, NULL, NULL),
(6, 'Mcc Ajah Lab', 0, NULL, NULL),
(7, 'Festac Bcp', 0, NULL, NULL),
(8, 'Ikeja Bcp', 0, NULL, NULL),
(9, 'Ibadan BCP', 0, NULL, NULL),
(10, 'Abeokuta BCP', 0, NULL, NULL),
(11, 'Sagamu BCP', 0, NULL, NULL),
(12, 'Ilorin BCP', 0, NULL, NULL),
(13, 'Enugu BCP', 0, NULL, NULL),
(14, 'PH BCP', 0, NULL, NULL),
(15, 'PH Lab', 0, NULL, NULL),
(16, 'Warri Lab', 0, NULL, NULL),
(17, 'Benni BCP', 0, NULL, NULL),
(18, 'Wuse BCP', 0, NULL, NULL),
(19, 'Gwarinpa Lab', 0, NULL, NULL),
(20, 'Gwagwalada BCP', 0, NULL, NULL),
(21, 'Kaduna BCP', 0, NULL, NULL),
(22, 'Asokoro BCP', 0, NULL, NULL),
(23, 'Ikotun BCP', 0, NULL, NULL),
(24, 'Ife BCP', 0, NULL, NULL),
(25, 'ISOS LAB', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `location_regions`
--

CREATE TABLE `location_regions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `location_regions`
--

INSERT INTO `location_regions` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'NORTH', '2023-01-20 10:02:51', '2023-01-20 10:02:51'),
(2, 'EAST', '2023-01-20 10:02:51', '2023-01-20 10:02:51'),
(3, 'LAGOS 2B', '2023-01-20 10:02:51', '2023-01-20 10:02:51'),
(4, 'WEST', '2023-01-20 10:02:51', '2023-01-20 10:02:51'),
(5, 'LAGOS 2A', '2023-01-20 10:02:52', '2023-01-20 10:02:52'),
(6, 'LAGOS 1', '2023-01-20 10:02:52', '2023-01-20 10:02:52');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_100000_create_password_resets_table', 1),
(2, '2019_08_19_000000_create_failed_jobs_table', 1),
(3, '2021_07_18_165508_create_admins_table', 1),
(4, '2021_07_29_170006_create_departments_table', 1),
(5, '2022_12_23_160904_create_users_table', 2),
(6, '2022_12_29_094348_create_location_regions_table', 2),
(7, '2022_12_29_094453_create_locations_table', 2),
(8, '2022_12_29_094523_create_query_categories_table', 2),
(9, '2022_12_31_160219_create_shipments_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `query_categories`
--

CREATE TABLE `query_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `query_categories`
--

INSERT INTO `query_categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'No Test Indicated', '2023-01-20 10:03:12', '2023-01-20 10:03:12'),
(2, 'Shipping Batch Not Received', '2023-01-20 10:03:12', '2023-01-20 10:03:12'),
(3, 'Bar Code Mixup', '2023-01-20 10:03:12', '2023-01-20 10:03:12'),
(4, 'Unlabelled Specimen', '2023-01-20 10:03:12', '2023-01-20 10:03:12'),
(5, 'No Sample Received', '2023-01-20 10:03:12', '2023-01-20 10:03:12'),
(6, 'Heamolysed Sample', '2023-01-20 10:03:12', '2023-01-20 10:03:12'),
(7, 'Broken Tube', '2023-01-20 10:03:12', '2023-01-20 10:03:12'),
(8, 'Wrong Collection Bottle/Container', '2023-01-20 10:03:13', '2023-01-20 10:03:13'),
(9, 'No Complete Biodata On Sample', '2023-01-20 10:03:13', '2023-01-20 10:03:13'),
(10, 'No Bar Code On Sample', '2023-01-20 10:03:13', '2023-01-20 10:03:13'),
(11, 'Sipllage/Empty Tube', '2023-01-20 10:03:13', '2023-01-20 10:03:13'),
(12, 'Un-seperated Sample', '2023-01-20 10:03:13', '2023-01-20 10:03:13'),
(13, 'Wrong Sample Received', '2023-01-20 10:03:13', '2023-01-20 10:03:13'),
(14, 'Insufficient Sample', '2023-01-20 10:03:13', '2023-01-20 10:03:13'),
(15, 'No Sample Type Stated', '2023-01-20 10:03:13', '2023-01-20 10:03:13'),
(16, 'Test Not Orderable', '2023-01-20 10:03:13', '2023-01-20 10:03:13'),
(17, 'Wrong Code Logged', '2023-01-20 10:03:13', '2023-01-20 10:03:13');

-- --------------------------------------------------------

--
-- Table structure for table `shipments`
--

CREATE TABLE `shipments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `location_region_id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` bigint(20) UNSIGNED NOT NULL COMMENT 'Received by this admin',
  `query_category_id` bigint(20) UNSIGNED NOT NULL,
  `date_of_shipment` date NOT NULL,
  `time_received` time NOT NULL,
  `batch_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `temperature` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_sample` int(11) NOT NULL,
  `number_of_sample_with_query` int(11) NOT NULL,
  `query_details` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `shipments`
--

INSERT INTO `shipments` (`id`, `location_id`, `location_region_id`, `admin_id`, `query_category_id`, `date_of_shipment`, `time_received`, `batch_number`, `temperature`, `number_of_sample`, `number_of_sample_with_query`, `query_details`, `created_at`, `updated_at`) VALUES
(1, 4, 5, 1, 2, '2023-01-09', '12:20:00', '89', '89', 6, 7, 'y', '2023-01-20 10:17:29', '2023-01-20 10:17:29');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobileNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `lastName`, `firstName`, `userName`, `email`, `email_verified_at`, `password`, `department`, `mobileNo`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Afolabi', 'Oluyosola', 'Oluyosola', 'oluyosolaafolabi@gmail.com', NULL, '$2y$10$Zl4Joqc1Q1zP7r0LVuK4rOxSL5w0JIKpvVFMxfcrzoQUjYKRhb1e.', NULL, '07069688056', NULL, '2023-01-20 10:15:08', '2023-01-20 10:15:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location_regions`
--
ALTER TABLE `location_regions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `query_categories`
--
ALTER TABLE `query_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipments`
--
ALTER TABLE `shipments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `location_regions`
--
ALTER TABLE `location_regions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `query_categories`
--
ALTER TABLE `query_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `shipments`
--
ALTER TABLE `shipments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
